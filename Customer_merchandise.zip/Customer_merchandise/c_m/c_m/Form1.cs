namespace c_m
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            def_customer customer_form = new def_customer();
            customer_form.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            def_merch merch_form = new def_merch();
            merch_form.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            customers_list cm_list = new customers_list();
            cm_list.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            merch_list mch_list = new merch_list();
            mch_list.Show();
        }
    }
}