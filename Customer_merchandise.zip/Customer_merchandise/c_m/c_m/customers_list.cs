﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace c_m
{
    public partial class customers_list : Form
    {
        public customers_list()
        {
            InitializeComponent();
        }

        private void customers_list_Load(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines("./customers.csv");
            foreach (string line in lines)
            {
                listBox1.Items.Add(line);
            }
        }
    }
}
